
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;

public class Query {

    private Connection con ;
    private Statement stmt ;
    public Vector heading;public Vector rows;
    private ResultSet res;
    private int length;

    public Query()
    {
         length=0;
         con = null;
         stmt = null;
         rows=null;
         heading=null;
         res=null;
    	 String sDriver = "com.mysql.jdbc.Driver";
    	 String sURL = "jdbc:mysql://localhost/Testing" ;
    	 String sUsername = "root";
    	 String sPassword = "";

         try
    	 {
       	 Class.forName(sDriver).newInstance();
         //JOptionPane.showMessageDialog(null, "MySQL Drivers Loaded Successfully");
         }
    	 catch( Exception e )
    	 {
         JOptionPane.showMessageDialog(null, "Problem loading MySQL Drivers");
   	 }

   	 try
    	 {
      	 con = DriverManager.getConnection( sURL, sUsername ,sPassword);
     	 stmt = con.createStatement();
	 if (stmt != null);
         //JOptionPane.showMessageDialog(null, "Connected to Database");
   	 }
    	 catch ( Exception e)
   	 {
         JOptionPane.showMessageDialog(null, "Problem Connecting to Server");
	 }
	
    }

    public boolean execute(String query)
    {
        boolean r;
      try
      {
          res=null;
          res=stmt.executeQuery(query);
          setHeading();setRows();
          r= true;
      }
      catch(SQLException e)
      {
          JOptionPane.showMessageDialog(null, "Invalid Query");
          e.printStackTrace();
          r= false;
      }
      finally
      {
            try {
                stmt.close();
                con.close();
            } catch (SQLException ex) {
              JOptionPane.showMessageDialog(null, "Error Closing Connection");
            }
      }
      return r;
    }

    private void setRows()
    {
        rows=new Vector();
        try {
            Vector<String> r = null;
            while (res.next()) {
                r = new Vector<String>();
                for (int k = 1; k <= length; k++)
                    r.add(res.getString(k));
                rows.add((Vector)r);
            }
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "Error retreiving rows");
        }

    }


    private void setHeading()
    {
        heading=new Vector();
        try {
            ResultSetMetaData a = res.getMetaData();
            length = a.getColumnCount();
            for (int k = 1; k <= length; k++) 
                heading.add(a.getColumnName(k));
            
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "Error retreiving columns");
        }
    }


}
