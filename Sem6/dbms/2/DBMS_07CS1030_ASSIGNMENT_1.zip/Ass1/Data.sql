-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 13, 2010 at 05:22 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user14`
--

-- --------------------------------------------------------

--
-- Table structure for table `Courses`
--

CREATE TABLE IF NOT EXISTS `Courses` (
  `Name` varchar(30) NOT NULL,
  `Description` varchar(150) NOT NULL,
  `CourseNo` varchar(20) NOT NULL,
  `Credits` int(5) NOT NULL,
  `Department` varchar(30) NOT NULL,
  PRIMARY KEY (`CourseNo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Courses`
--

INSERT INTO `Courses` (`Name`, `Description`, `CourseNo`, `Credits`, `Department`) VALUES
('Database Management Systems', 'Databases Learning', 'CS43002', 5, 'CS'),
('Operating systems', 'Windows,Linux', 'CS30010', 3, 'CS'),
('ThermoDynamics', 'Heat and Fun', 'ME30102', 4, 'ME'),
('Elastics', 'Rubber band', 'ME50101', 4, 'ME'),
('Digital Signal Processing', 'Digitized world', 'EC31010', 4, 'EC'),
('Microwave Engineering', 'learn from the best', 'EC32010', 3, 'EC');

-- --------------------------------------------------------

--
-- Table structure for table `Departments`
--

CREATE TABLE IF NOT EXISTS `Departments` (
  `Name` varchar(100) NOT NULL,
  `Code` varchar(20) NOT NULL,
  `OfficeNo` varchar(20) NOT NULL,
  `OfficePhone` int(15) NOT NULL,
  `College` varchar(30) NOT NULL,
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `Code` (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Departments`
--

INSERT INTO `Departments` (`Name`, `Code`, `OfficeNo`, `OfficePhone`, `College`) VALUES
('Computer Science and Engineering', 'CS', '101', 821502, 'IIT KGP'),
('Mechanical Engineering', 'ME', '102', 821230, 'IIT KGP'),
('Electronics and Electrical Communication Engineering', 'EC', '103', 821510, 'IIT KGP');

-- --------------------------------------------------------

--
-- Table structure for table `Grades`
--

CREATE TABLE IF NOT EXISTS `Grades` (
  `Student` varchar(30) NOT NULL,
  `SectionNo` varchar(30) NOT NULL,
  `Grade` varchar(3) NOT NULL,
  UNIQUE KEY `Student` (`Student`,`SectionNo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Grades`
--

INSERT INTO `Grades` (`Student`, `SectionNo`, `Grade`) VALUES
('07CS1013', '1', 'A'),
('07CS1013', '2', 'A'),
('07CS1030', '1', 'B'),
('07CS1030', '2', 'B'),
('07CS1039', '1', 'C'),
('07CS1039', '2', 'C'),
('07CS3018', '1', 'A'),
('07CS3018', '3', 'C'),
('07EC1006', '3', 'A'),
('07EC1006', '4', 'D'),
('07EC1010', '3', 'A'),
('07EC1010', '4', 'X'),
('07EC1012', '3', 'A'),
('07EC1012', '1', 'A'),
('07EC1031', '3', 'A'),
('07EC1031', '4', 'A'),
('07ME1001', '5', 'A'),
('07ME1001', '6', 'C'),
('07ME1021', '5', 'D'),
('07ME1021', '2', 'A'),
('07ME1029', '5', 'A'),
('07ME1029', '6', 'C'),
('07ME3010', '6', 'C'),
('07ME3010', '3', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `Section`
--

CREATE TABLE IF NOT EXISTS `Section` (
  `Instructor` varchar(50) NOT NULL,
  `Semester` varchar(20) NOT NULL,
  `Year` int(5) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `SectionNo` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`SectionNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Section`
--

INSERT INTO `Section` (`Instructor`, `Semester`, `Year`, `Course`, `SectionNo`) VALUES
('Pabitra Mitra', 'Spring', 2010, 'CS43002', 1),
('Indranik Sengupta', 'Spring', 2010, 'CS30010', 2),
('Raja Kumar', 'Spring', 2010, 'EC31010', 3),
('DebKumar', 'Spring', 2010, 'EC32010', 4),
('Chatterjee', 'Spring', 2010, 'ME30102', 5),
('Kashyap Majumdhar', 'Spring', 2010, 'ME50101', 6);

-- --------------------------------------------------------

--
-- Table structure for table `Students`
--

CREATE TABLE IF NOT EXISTS `Students` (
  `Name` varchar(25) NOT NULL,
  `SSN` varchar(20) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone` int(12) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Degree` varchar(20) NOT NULL,
  PRIMARY KEY (`SSN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Students`
--

INSERT INTO `Students` (`Name`, `SSN`, `Address`, `Phone`, `DateOfBirth`, `Department`, `Degree`) VALUES
('Srnivas Tella', '07CS1039', 'RK HAll', 2147483647, '1989-03-21', 'CS', 'B.Tech'),
('Adil Hayat', '07ME1021', 'RP Hall', 893723882, '1992-01-22', 'ME', 'B.Tech'),
('Maruti Srinivas', '07CS1030', 'Rk HAll', 2147483647, '1989-03-21', 'CS', 'B.Tech'),
('Devaroy', '07CS1013', 'Azad Hall', 2147483647, '1989-09-26', 'CS', 'B.Tech'),
('Tella Nandish', '07CS3018', 'MS HAll', 2147483647, '1989-03-21', 'CS', 'Dual'),
('Rohit Kumar', '07ME3010', 'RK HAll', 2147483647, '1989-03-21', 'ME', 'Dual'),
('Anuj Kodam', '07ME1029', 'RK HAll', 2147483647, '1989-03-21', 'ME', 'B.Tech'),
('Kolla Abhinav Sai', '07ME1001', 'PT HAll', 2147483647, '1989-03-21', 'ME', 'B.tech'),
('Surya Teja', '07EC1010', 'RK HAll', 2147483647, '1989-03-21', 'EC', 'B.Tech'),
('Vivek', '07EC1031', 'RK HAll', 2147483647, '1989-03-21', 'EC', 'B.Tech'),
('Nitish V', '07EC1012', 'RK HAll', 2147483647, '1989-03-21', 'EC', 'B.tech'),
('Bogela Sagar', '07EC1006', 'JCB Hall', 291827297, '1988-07-19', 'EC', 'B.tech');
