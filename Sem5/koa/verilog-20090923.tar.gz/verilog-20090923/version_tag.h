#ifndef VERSION_TAG
#define VERSION_TAG "s20090923"
#endif
