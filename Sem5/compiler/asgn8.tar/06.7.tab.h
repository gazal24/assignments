
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     START = 258,
     END = 259,
     CODE = 260,
     INT = 261,
     FLOAT = 262,
     STRING = 263,
     VAR = 264,
     WHILE = 265,
     FOR = 266,
     EXITLOOP = 267,
     SKIP = 268,
     ELSE = 269,
     PROTO = 270,
     PROC = 271,
     TO = 272,
     STEP = 273,
     NIL = 274,
     IF = 275,
     INC = 276,
     DEC = 277,
     PLUS = 278,
     MINUS = 279,
     MULT = 280,
     DIV = 281,
     OR = 282,
     EQ = 283,
     NE = 284,
     GT = 285,
     GE = 286,
     LT = 287,
     LE = 288,
     NOT = 289,
     AND = 290,
     CALL = 291,
     IN = 292,
     OUT = 293,
     MOD = 294,
     RETURN = 295,
     ASSIGN = 296,
     FETCH = 297,
     LFT_PAREN = 298,
     RGT_PAREN = 299,
     LFT_BRACE = 300,
     RGT_BRACE = 301,
     LFT_SQ_BKT = 302,
     RGT_SQ_BKT = 303,
     COMMA = 304,
     COLON = 305,
     SEMICOLON = 306,
     DOT = 307,
     INT_CONST = 308,
     FLOAT_CONST = 309,
     IDENTIFIER = 310,
     UPOS = 311,
     UNEG = 312
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 31 "06.7.y"
                /* INTEGER of 'yylval' (stack INTEGER)*/
  char *string;
  int integer, operator;           /* INTEGER name is YYSTYPE*/
  double real;            /* default #define YYSTYPE int ple ty*/
  struct lst * nl;
  struct symNode *pointer;
  int* nxtq;
  struct tfl{
  	struct lst * tl;
  	struct lst * fl;
  }bexp;
  struct expr{
  	double val;
  	struct symNode *addr;
  	char pos;//left or right
  }expr;



/* Line 1676 of yacc.c  */
#line 129 "06.7.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


