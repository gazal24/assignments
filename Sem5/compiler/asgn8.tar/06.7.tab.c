
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 1 "06.7.y"

#include <stdio.h>
#include "06.7.tab.h"
#include "lex.yy.c"
#include "symTab.h"

#define VAR_DECL 100
#define USE_CASE 110
#define YYDEBUG 500       /* enables compilation with trace fac*/
#define N 500
	
  symnode symbol;	// helps to determine various field of an identifier
  int contxt, offset, *dimList, dimcount=0;
  symtab* rootSymT, *currentSymT;
  unsigned int InterCode[N][5], nq, _cnt_=0;


	int yylex (void);       /* INTEGER of yylex() */
	void yyerror(char const *s);
	void backPatch(List *a, int* val);
	void code(int op, unsigned int op1,unsigned int op2, symnode * dest, int check);
	void deleteList(List *a);
	char* genTemp();
	List *mergeList(List *a, List *b);
	List *makeList(int num);
	void printCode();
	void printTAC();
	void writeVerbatim(int option, FILE *fp);


/* Line 189 of yacc.c  */
#line 104 "06.7.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     START = 258,
     END = 259,
     CODE = 260,
     INT = 261,
     FLOAT = 262,
     STRING = 263,
     VAR = 264,
     WHILE = 265,
     FOR = 266,
     EXITLOOP = 267,
     SKIP = 268,
     ELSE = 269,
     PROTO = 270,
     PROC = 271,
     TO = 272,
     STEP = 273,
     NIL = 274,
     IF = 275,
     INC = 276,
     DEC = 277,
     PLUS = 278,
     MINUS = 279,
     MULT = 280,
     DIV = 281,
     OR = 282,
     EQ = 283,
     NE = 284,
     GT = 285,
     GE = 286,
     LT = 287,
     LE = 288,
     NOT = 289,
     AND = 290,
     CALL = 291,
     IN = 292,
     OUT = 293,
     MOD = 294,
     RETURN = 295,
     ASSIGN = 296,
     FETCH = 297,
     LFT_PAREN = 298,
     RGT_PAREN = 299,
     LFT_BRACE = 300,
     RGT_BRACE = 301,
     LFT_SQ_BKT = 302,
     RGT_SQ_BKT = 303,
     COMMA = 304,
     COLON = 305,
     SEMICOLON = 306,
     DOT = 307,
     INT_CONST = 308,
     FLOAT_CONST = 309,
     IDENTIFIER = 310,
     UPOS = 311,
     UNEG = 312
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 31 "06.7.y"
                /* INTEGER of 'yylval' (stack INTEGER)*/
  char *string;
  int integer, operator;           /* INTEGER name is YYSTYPE*/
  double real;            /* default #define YYSTYPE int ple ty*/
  struct lst * nl;
  struct symNode *pointer;
  int* nxtq;
  struct tfl{
  	struct lst * tl;
  	struct lst * fl;
  }bexp;
  struct expr{
  	double val;
  	struct symNode *addr;
  	char pos;//left or right
  }expr;



/* Line 214 of yacc.c  */
#line 217 "06.7.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 229 "06.7.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  5
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   248

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  58
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  42
/* YYNRULES -- Number of rules.  */
#define YYNRULES  89
/* YYNRULES -- Number of states.  */
#define YYNSTATES  167

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   312

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     8,    11,    14,    17,    18,    20,    22,
      23,    28,    31,    33,    36,    38,    40,    43,    45,    48,
      51,    52,    56,    64,    70,    73,    74,    78,    80,    82,
      86,    88,    90,    92,    94,    96,    98,   100,   102,   104,
     106,   108,   110,   114,   117,   120,   121,   125,   129,   132,
     135,   138,   148,   155,   160,   165,   168,   172,   176,   178,
     180,   182,   184,   186,   188,   198,   205,   207,   209,   215,
     219,   223,   227,   231,   235,   238,   241,   243,   245,   249,
     251,   254,   257,   262,   266,   268,   269,   271,   274,   275
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      59,     0,    -1,     5,    60,    98,     4,    -1,    61,    77,
      -1,    61,    62,    -1,    61,    63,    -1,    -1,    72,    -1,
      73,    -1,    -1,     9,    64,    65,    51,    -1,    65,    66,
      -1,    66,    -1,    67,    68,    -1,     6,    -1,     7,    -1,
      68,    69,    -1,    69,    -1,    55,    70,    -1,    70,    71,
      -1,    -1,    47,    53,    48,    -1,    16,    55,    74,    50,
      76,    60,    52,    -1,    15,    55,    74,    50,    76,    -1,
      74,    75,    -1,    -1,    69,    50,    67,    -1,    67,    -1,
      19,    -1,    77,    98,    78,    -1,    78,    -1,    79,    -1,
      83,    -1,    84,    -1,    85,    -1,    86,    -1,    89,    -1,
      90,    -1,    91,    -1,    92,    -1,    93,    -1,    97,    -1,
      80,    41,    94,    -1,    55,    81,    -1,    81,    82,    -1,
      -1,    47,    94,    48,    -1,     3,    77,    52,    -1,    37,
      80,    -1,    38,     8,    -1,    38,    94,    -1,    20,    87,
      98,    50,    78,    99,    14,    98,    78,    -1,    20,    87,
      98,    50,    78,    50,    -1,    87,    27,    98,    87,    -1,
      87,    35,    98,    87,    -1,    34,    87,    -1,    43,    87,
      44,    -1,    94,    88,    94,    -1,    28,    -1,    33,    -1,
      32,    -1,    31,    -1,    30,    -1,    29,    -1,    11,    80,
      41,    94,    17,    94,    18,    94,    78,    -1,    10,    98,
      87,    50,    98,    78,    -1,    12,    -1,    13,    -1,    36,
      55,    43,    95,    44,    -1,    94,    23,    94,    -1,    94,
      24,    94,    -1,    94,    25,    94,    -1,    94,    26,    94,
      -1,    94,    39,    94,    -1,    24,    94,    -1,    23,    94,
      -1,    53,    -1,    54,    -1,    43,    94,    44,    -1,    80,
      -1,    22,    80,    -1,    21,    80,    -1,    55,    43,    95,
      44,    -1,    96,    49,    95,    -1,    96,    -1,    -1,    69,
      -1,    40,    94,    -1,    -1,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    81,    81,    83,    85,    86,    87,    89,    90,    92,
      92,    94,    95,    97,   107,   108,   110,   116,   122,   124,
     125,   139,   141,   144,   146,   147,   149,   151,   152,   154,
     155,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   169,   171,   191,   198,   200,   202,   204,   206,
     207,   209,   210,   212,   213,   214,   215,   216,   223,   224,
     225,   226,   227,   228,   230,   237,   244,   246,   248,   250,
     252,   254,   256,   258,   260,   262,   264,   269,   271,   272,
     273,   275,   277,   279,   280,   281,   283,   285,   288,   290
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "START", "END", "CODE", "INT", "FLOAT",
  "STRING", "VAR", "WHILE", "FOR", "EXITLOOP", "SKIP", "ELSE", "PROTO",
  "PROC", "TO", "STEP", "NIL", "IF", "INC", "DEC", "PLUS", "MINUS", "MULT",
  "DIV", "OR", "EQ", "NE", "GT", "GE", "LT", "LE", "NOT", "AND", "CALL",
  "IN", "OUT", "MOD", "RETURN", "ASSIGN", "FETCH", "LFT_PAREN",
  "RGT_PAREN", "LFT_BRACE", "RGT_BRACE", "LFT_SQ_BKT", "RGT_SQ_BKT",
  "COMMA", "COLON", "SEMICOLON", "DOT", "INT_CONST", "FLOAT_CONST",
  "IDENTIFIER", "UPOS", "UNEG", "$accept", "prog", "body", "procVarDecl",
  "procDecl", "varDecl", "$@1", "varDeclList", "typeAndVar", "type",
  "idList", "idd", "dimList", "dim", "procDef", "procProto",
  "formParamList", "formParam", "retType", "stmtList", "stmt",
  "assignmentStmt", "id", "indList", "index", "compStmt", "inStmt",
  "outStmt", "ifStmt", "bExp", "relOp", "forStmt", "whileStmt", "exitLoop",
  "nullStmt", "procStmt", "exp", "actParamList", "actParam", "returnStmt",
  "M", "N", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    58,    59,    60,    61,    61,    61,    62,    62,    64,
      63,    65,    65,    66,    67,    67,    68,    68,    69,    70,
      70,    71,    72,    73,    74,    74,    75,    76,    76,    77,
      77,    78,    78,    78,    78,    78,    78,    78,    78,    78,
      78,    78,    79,    80,    81,    81,    82,    83,    84,    85,
      85,    86,    86,    87,    87,    87,    87,    87,    88,    88,
      88,    88,    88,    88,    89,    90,    91,    92,    93,    94,
      94,    94,    94,    94,    94,    94,    94,    94,    94,    94,
      94,    94,    94,    95,    95,    95,    96,    97,    98,    99
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     4,     2,     2,     2,     0,     1,     1,     0,
       4,     2,     1,     2,     1,     1,     2,     1,     2,     2,
       0,     3,     7,     5,     2,     0,     3,     1,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     3,     2,     2,     0,     3,     3,     2,     2,
       2,     9,     6,     4,     4,     2,     3,     3,     1,     1,
       1,     1,     1,     1,     9,     6,     1,     1,     5,     3,
       3,     3,     3,     3,     2,     2,     1,     1,     3,     1,
       2,     2,     4,     3,     1,     0,     1,     2,     0,     0
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     6,     0,    88,     0,     1,     0,     0,     9,    88,
       0,    66,    67,     0,     0,     0,     0,     0,     0,     0,
      45,     4,     5,     7,     8,    88,    30,    31,     0,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,     2,
      88,     0,     0,     0,    25,    25,     0,     0,     0,     0,
       0,     0,    76,    77,    45,    79,    88,     0,     0,    48,
      49,     0,    50,    87,    43,     0,     0,    47,    14,    15,
       0,    12,     0,     0,     0,     0,     0,    81,    80,    75,
      74,    55,     0,     0,    85,    88,    88,     0,     0,     0,
       0,     0,    58,    63,    62,    61,    60,    59,     0,     0,
      85,     0,     0,    44,    29,    42,    10,    11,    20,    13,
      17,    88,     0,     0,     0,    24,     0,    56,    78,    86,
       0,    84,     0,     0,     0,    69,    70,    71,    72,    73,
      57,     0,     0,    18,    16,     0,     0,    28,    27,    23,
       0,     6,    82,    85,    53,    54,    89,    68,    46,     0,
      19,    65,     0,    26,     0,    83,    52,     0,     0,     0,
      22,    88,    21,     0,     0,    64,    51
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     3,     4,    21,    22,    41,    70,    71,    72,
     109,   119,   133,   150,    23,    24,    75,   115,   139,    25,
      26,    27,    55,    64,   103,    29,    30,    31,    32,    56,
      99,    33,    34,    35,    36,    37,    57,   120,   121,    38,
      65,   157
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -89
static const yytype_int16 yypact[] =
{
       0,   -89,    16,   -89,    98,   -89,    13,   130,   -89,   -89,
     -18,   -89,   -89,   -15,    -3,   154,    11,   -18,   150,   101,
     -89,   -89,   -89,   -89,   -89,    -2,   -89,   -89,   -14,   -89,
     -89,   -89,   -89,   -89,   -89,   -89,   -89,   -89,   -89,   -89,
      31,    52,   154,    29,   -89,   -89,   -18,   -18,   101,   101,
     154,   154,   -89,   -89,    41,   -89,    27,   209,    42,   -89,
     -89,   101,   122,   122,    44,   130,   101,   -89,   -89,   -89,
      18,   -89,    43,   -20,   101,    17,    77,   -89,   -89,   -89,
     -89,   -89,    38,   187,    43,   -89,   -89,    65,   101,   101,
     101,   101,   -89,   -89,   -89,   -89,   -89,   -89,   101,   101,
      43,   156,   101,   -89,   -89,   122,   -89,   -89,   -89,    43,
     -89,   -89,    51,   110,    71,   -89,   110,   -89,   -89,   -89,
      58,    88,   154,   154,   130,    10,    10,   -89,   -89,   -89,
     122,    95,    80,   104,   -89,   130,   101,   -89,   -89,   -89,
      52,   -89,   -89,    43,   -89,   -89,   102,   -89,   -89,   111,
     -89,   -89,   204,   -89,   105,   -89,   -89,   149,   117,   101,
     -89,   -89,   -89,     8,   130,   -89,   -89
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -89,   -89,    28,   -89,   -89,   -89,   -89,   -89,   113,   -87,
     -89,    21,   -89,   -89,   -89,   -89,   139,   -89,    70,   180,
     -64,   -89,    -4,   -89,   -89,   -89,   -89,   -89,   -89,   -28,
     -89,   -89,   -89,   -89,   -89,   -89,   -10,   -88,   -89,   -89,
       1,   -89
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -4
static const yytype_int16 yytable[] =
{
      28,   104,    -3,    28,     6,     1,    43,    85,    62,    63,
      42,     7,   131,    59,    73,    86,     5,    39,     9,    10,
      11,    12,    81,    82,    68,    69,   138,    66,    15,   138,
     111,    88,    89,    90,    91,    90,    91,    20,    79,    80,
      44,    83,    77,    78,    16,    17,    18,    98,    19,    98,
      -3,   101,    45,   153,    85,   155,   105,    87,    68,    69,
     146,    28,    86,    20,   112,    85,    58,   113,   136,   106,
      74,   151,   108,    86,    88,    89,    90,    91,   125,   126,
     127,   128,   117,    67,    84,   100,   122,   123,   129,   130,
      98,   102,   132,   110,   144,   145,   114,   114,   108,   165,
     166,     7,   142,    88,    89,    90,    91,     8,     9,    10,
      11,    12,   135,    13,    14,   124,    68,    69,    15,    98,
      28,   140,    46,    47,    48,    49,   152,   116,   148,   137,
     134,    28,   108,     7,    16,    17,    18,   143,    19,   147,
       9,    10,    11,    12,    61,    88,    89,    90,    91,   163,
      15,   149,   156,    20,    52,    53,    54,   160,    60,    28,
      28,    98,   164,   161,   158,   162,    16,    17,    18,   154,
      19,    46,    47,    48,    49,    46,    47,    48,    49,    88,
      89,    90,    91,   107,    76,    20,   141,    40,    50,     0,
       0,     0,     0,    61,     0,    98,     0,    51,     0,     0,
     118,     0,     0,    52,    53,    54,     0,    52,    53,    54,
      88,    89,    90,    91,     0,    92,    93,    94,    95,    96,
      97,     0,   159,     0,     0,     0,    98,    88,    89,    90,
      91,   118,    88,    89,    90,    91,     0,    92,    93,    94,
      95,    96,    97,    98,     0,     0,     0,     0,    98
};

static const yytype_int16 yycheck[] =
{
       4,    65,     4,     7,     3,     5,    10,    27,    18,    19,
       9,     3,   100,    17,    42,    35,     0,     4,    10,    11,
      12,    13,    50,    51,     6,     7,   113,    41,    20,   116,
      50,    23,    24,    25,    26,    25,    26,    55,    48,    49,
      55,    51,    46,    47,    36,    37,    38,    39,    40,    39,
      52,    61,    55,   140,    27,   143,    66,    56,     6,     7,
     124,    65,    35,    55,    74,    27,    55,    50,    17,    51,
      41,   135,    55,    35,    23,    24,    25,    26,    88,    89,
      90,    91,    44,    52,    43,    43,    85,    86,    98,    99,
      39,    47,   102,    72,   122,   123,    75,    76,    55,   163,
     164,     3,    44,    23,    24,    25,    26,     9,    10,    11,
      12,    13,   111,    15,    16,    50,     6,     7,    20,    39,
     124,    50,    21,    22,    23,    24,   136,    50,    48,    19,
     109,   135,    55,     3,    36,    37,    38,    49,    40,    44,
      10,    11,    12,    13,    43,    23,    24,    25,    26,   159,
      20,    47,    50,    55,    53,    54,    55,    52,     8,   163,
     164,    39,   161,    14,    53,    48,    36,    37,    38,   141,
      40,    21,    22,    23,    24,    21,    22,    23,    24,    23,
      24,    25,    26,    70,    45,    55,   116,     7,    34,    -1,
      -1,    -1,    -1,    43,    -1,    39,    -1,    43,    -1,    -1,
      44,    -1,    -1,    53,    54,    55,    -1,    53,    54,    55,
      23,    24,    25,    26,    -1,    28,    29,    30,    31,    32,
      33,    -1,    18,    -1,    -1,    -1,    39,    23,    24,    25,
      26,    44,    23,    24,    25,    26,    -1,    28,    29,    30,
      31,    32,    33,    39,    -1,    -1,    -1,    -1,    39
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     5,    59,    60,    61,     0,    98,     3,     9,    10,
      11,    12,    13,    15,    16,    20,    36,    37,    38,    40,
      55,    62,    63,    72,    73,    77,    78,    79,    80,    83,
      84,    85,    86,    89,    90,    91,    92,    93,    97,     4,
      77,    64,    98,    80,    55,    55,    21,    22,    23,    24,
      34,    43,    53,    54,    55,    80,    87,    94,    55,    80,
       8,    43,    94,    94,    81,    98,    41,    52,     6,     7,
      65,    66,    67,    87,    41,    74,    74,    80,    80,    94,
      94,    87,    87,    94,    43,    27,    35,    98,    23,    24,
      25,    26,    28,    29,    30,    31,    32,    33,    39,    88,
      43,    94,    47,    82,    78,    94,    51,    66,    55,    68,
      69,    50,    94,    50,    69,    75,    50,    44,    44,    69,
      95,    96,    98,    98,    50,    94,    94,    94,    94,    94,
      94,    95,    94,    70,    69,    98,    17,    19,    67,    76,
      50,    76,    44,    49,    87,    87,    78,    44,    48,    47,
      71,    78,    94,    67,    60,    95,    50,    99,    53,    18,
      52,    14,    48,    94,    98,    78,    78
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1455 of yacc.c  */
#line 81 "06.7.y"
    {backPatch((yyvsp[(2) - (4)].nl), (yyvsp[(3) - (4)].nxtq));;}
    break;

  case 3:

/* Line 1455 of yacc.c  */
#line 83 "06.7.y"
    {(yyval.nl)=(yyvsp[(2) - (2)].nl);}
    break;

  case 9:

/* Line 1455 of yacc.c  */
#line 92 "06.7.y"
    {contxt = DEF;offset=0;;}
    break;

  case 10:

/* Line 1455 of yacc.c  */
#line 92 "06.7.y"
    {printId(currentSymT);contxt=USE;}
    break;

  case 13:

/* Line 1455 of yacc.c  */
#line 97 "06.7.y"
    {
								List *t=(yyvsp[(2) - (2)].nl);
								if((yyvsp[(1) - (2)].integer) != INTEGER);								
								while(t){
									((symnode *)t)->type=(yyvsp[(1) - (2)].integer);
									t=t->next;
									}
								deleteList((yyvsp[(2) - (2)].nl))
							;}
    break;

  case 14:

/* Line 1455 of yacc.c  */
#line 107 "06.7.y"
    {(yyval.integer)=INTEGER;;}
    break;

  case 15:

/* Line 1455 of yacc.c  */
#line 108 "06.7.y"
    {(yyval.integer)=DOUBLE;;}
    break;

  case 16:

/* Line 1455 of yacc.c  */
#line 110 "06.7.y"
    {
	
								symnode *tmp=searchInsert(currentSymT, contxt, (yyvsp[(2) - (2)].string), INTEGER, dimList,NULL,  offset);dimList[0]=-1;
								offset+=4;
								(yyval.nl)=mergeList((yyvsp[(1) - (2)].nl), makeList((int)tmp));
							;}
    break;

  case 17:

/* Line 1455 of yacc.c  */
#line 116 "06.7.y"
    {	
     							symnode *tmp=searchInsert(currentSymT, contxt, (yyvsp[(1) - (1)].string), INTEGER, dimList,NULL, offset);dimList[0]=-1;
     							offset+=4;
								(yyval.nl)=makeList((int)tmp);
     						;}
    break;

  case 18:

/* Line 1455 of yacc.c  */
#line 122 "06.7.y"
    {(yyval.string)=(yyvsp[(1) - (2)].string);;}
    break;

  case 19:

/* Line 1455 of yacc.c  */
#line 124 "06.7.y"
    {(yyval.nl)=mergeList((yyvsp[(1) - (2)].nl), makeList((yyvsp[(2) - (2)].integer)));dimcount++;}
    break;

  case 20:

/* Line 1455 of yacc.c  */
#line 125 "06.7.y"
    {
     							if((yyval.nl)) 
     								(yyval.nl)->next=NULL;dimList=(int *)malloc(sizeof(int)*dimcount);
     							(yyval.nl)=NULL;
     							List *t=(yyval.nl);
     							int i=0;
								while(t){
									dimList[i++]=t->val;
									t=t->next;
								}
								dimList[i++]=-1;
								deleteList((yyval.nl));
     						;}
    break;

  case 21:

/* Line 1455 of yacc.c  */
#line 139 "06.7.y"
    {(yyval.integer)=(yyvsp[(2) - (3)].integer);}
    break;

  case 29:

/* Line 1455 of yacc.c  */
#line 154 "06.7.y"
    {backPatch((yyvsp[(1) - (3)].nl), (yyvsp[(2) - (3)].nxtq)); (yyval.nl)=(yyvsp[(3) - (3)].nl);}
    break;

  case 30:

/* Line 1455 of yacc.c  */
#line 155 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 31:

/* Line 1455 of yacc.c  */
#line 157 "06.7.y"
    {deleteList((yyval.nl));(yyval.nl)=NULL;}
    break;

  case 32:

/* Line 1455 of yacc.c  */
#line 158 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 33:

/* Line 1455 of yacc.c  */
#line 159 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 160 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 35:

/* Line 1455 of yacc.c  */
#line 161 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 36:

/* Line 1455 of yacc.c  */
#line 162 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 37:

/* Line 1455 of yacc.c  */
#line 163 "06.7.y"
    {(yyval.nl)=(yyvsp[(1) - (1)].nl);}
    break;

  case 38:

/* Line 1455 of yacc.c  */
#line 164 "06.7.y"
    {(yyval.nl)=NULL;}
    break;

  case 39:

/* Line 1455 of yacc.c  */
#line 165 "06.7.y"
    {(yyval.nl)=NULL;}
    break;

  case 40:

/* Line 1455 of yacc.c  */
#line 166 "06.7.y"
    {(yyval.nl)=NULL;}
    break;

  case 41:

/* Line 1455 of yacc.c  */
#line 167 "06.7.y"
    {(yyval.nl)=NULL;}
    break;

  case 42:

/* Line 1455 of yacc.c  */
#line 169 "06.7.y"
    {(yyval.nl)=NULL;code(ASSIGN, (unsigned int)(yyvsp[(3) - (3)].expr).addr, 0,(yyvsp[(1) - (3)].expr).addr, 0); ;}
    break;

  case 43:

/* Line 1455 of yacc.c  */
#line 171 "06.7.y"
    {
								(yyval.expr).addr=searchInsert(currentSymT, contxt, (yyvsp[(1) - (2)].string), INTEGER, dimList, NULL, 0);dimList[0]=-1;
								if((yyvsp[(2) - (2)].nl)){
									symnode * tmp;
									tmp=searchInsert(currentSymT, contxt, genTemp(), INTEGER, NULL, NULL, 0);
									if((yyval.expr).pos=='L') code(PLUS,(unsigned int)(yyval.expr).addr,(yyvsp[(2) - (2)].nl)->val, tmp, 2); 
									code(FETCH,(unsigned int) (yyval.expr).addr, (unsigned int)tmp, tmp, 0);
									deleteList((yyvsp[(2) - (2)].nl));
								}
								/*List *t=$2;
								symnode *iden=$$.addr;
								int i=0;
								symnode * tmp;
								while(t){
									tmp=searchInsert(currentSymT, contxt, genTemp(), INTEGER, NULL, NULL, 0);
									tmp->value.var=iden->dimList;
									//code(MULT, tmp, );
									}*/
							;}
    break;

  case 44:

/* Line 1455 of yacc.c  */
#line 191 "06.7.y"
    {
								//$$=mergeList($1, makeList((unsigned int)$2.addr))}
								symnode * tmp;
								tmp=searchInsert(currentSymT, contxt, genTemp(), INTEGER, NULL, NULL, 0);
								code(MULT, (unsigned int) (yyvsp[(2) - (2)].expr).addr,4, tmp, 2);
								(yyval.nl)=makeList((unsigned int)tmp);
							;}
    break;

  case 45:

/* Line 1455 of yacc.c  */
#line 198 "06.7.y"
    {(yyval.nl)=NULL;;}
    break;

  case 46:

/* Line 1455 of yacc.c  */
#line 200 "06.7.y"
    {(yyval.expr).addr=(yyvsp[(2) - (3)].expr).addr;}
    break;

  case 47:

/* Line 1455 of yacc.c  */
#line 202 "06.7.y"
    {(yyval.nl)=(yyvsp[(2) - (3)].nl);}
    break;

  case 48:

/* Line 1455 of yacc.c  */
#line 204 "06.7.y"
    {(yyval.nl)=NULL;code(IN, 0,0, (yyvsp[(2) - (2)].expr).addr, 0);}
    break;

  case 49:

/* Line 1455 of yacc.c  */
#line 206 "06.7.y"
    {(yyval.nl)=NULL;code(OUT, 0,0, (symnode*)NULL, 0);}
    break;

  case 50:

/* Line 1455 of yacc.c  */
#line 207 "06.7.y"
    {(yyval.nl)=NULL;code(OUT, 0,0, (yyvsp[(2) - (2)].expr).addr, 0);}
    break;

  case 51:

/* Line 1455 of yacc.c  */
#line 209 "06.7.y"
    {backPatch((yyvsp[(2) - (9)].bexp).tl, (yyvsp[(3) - (9)].nxtq));backPatch((yyvsp[(2) - (9)].bexp).fl, (yyvsp[(8) - (9)].nxtq)); (yyval.nl)=mergeList((yyvsp[(5) - (9)].nl), mergeList((yyvsp[(6) - (9)].nl), (yyvsp[(9) - (9)].nl)));}
    break;

  case 52:

/* Line 1455 of yacc.c  */
#line 210 "06.7.y"
    {backPatch((yyvsp[(2) - (6)].bexp).tl, (yyvsp[(3) - (6)].nxtq));(yyval.nl)=mergeList((yyvsp[(2) - (6)].bexp).fl,(yyvsp[(5) - (6)].nl));}
    break;

  case 53:

/* Line 1455 of yacc.c  */
#line 212 "06.7.y"
    {(yyval.bexp).fl=(yyvsp[(4) - (4)].bexp).fl;(yyval.bexp).tl=mergeList((yyvsp[(1) - (4)].bexp).tl,(yyvsp[(4) - (4)].bexp).tl); backPatch((yyvsp[(1) - (4)].bexp).fl, (yyvsp[(3) - (4)].nxtq));}
    break;

  case 54:

/* Line 1455 of yacc.c  */
#line 213 "06.7.y"
    {(yyval.bexp).tl=(yyvsp[(4) - (4)].bexp).tl;(yyval.bexp).fl=mergeList((yyvsp[(1) - (4)].bexp).fl,(yyvsp[(4) - (4)].bexp).fl); backPatch((yyvsp[(1) - (4)].bexp).tl, (yyvsp[(3) - (4)].nxtq));}
    break;

  case 55:

/* Line 1455 of yacc.c  */
#line 214 "06.7.y"
    {(yyval.bexp).tl=(yyvsp[(2) - (2)].bexp).fl; (yyval.bexp).fl=(yyvsp[(2) - (2)].bexp).tl;;}
    break;

  case 56:

/* Line 1455 of yacc.c  */
#line 215 "06.7.y"
    {(yyval.bexp).tl=(yyvsp[(2) - (3)].bexp).tl; (yyval.bexp).fl=(yyvsp[(2) - (3)].bexp).fl;;}
    break;

  case 57:

/* Line 1455 of yacc.c  */
#line 216 "06.7.y"
    {
     							//$$.tl=makeList(nq); 
     							(yyval.bexp).fl=makeList(nq); 
     							code(revOP((yyvsp[(2) - (3)].operator)),(unsigned int)(yyvsp[(1) - (3)].expr).addr,(unsigned int)(yyvsp[(3) - (3)].expr).addr,NULL, 0); 
     							//code(0,0,0,0);
     						;}
    break;

  case 58:

/* Line 1455 of yacc.c  */
#line 223 "06.7.y"
    {(yyval.operator)=EQ;}
    break;

  case 59:

/* Line 1455 of yacc.c  */
#line 224 "06.7.y"
    {(yyval.operator)=LE;}
    break;

  case 60:

/* Line 1455 of yacc.c  */
#line 225 "06.7.y"
    {(yyval.operator)=LT;}
    break;

  case 61:

/* Line 1455 of yacc.c  */
#line 226 "06.7.y"
    {(yyval.operator)=GE;}
    break;

  case 62:

/* Line 1455 of yacc.c  */
#line 227 "06.7.y"
    {(yyval.operator)=GT;}
    break;

  case 63:

/* Line 1455 of yacc.c  */
#line 228 "06.7.y"
    {(yyval.operator)=NE;}
    break;

  case 64:

/* Line 1455 of yacc.c  */
#line 231 "06.7.y"
    {
								code(ASSIGN, (unsigned int)(yyvsp[(4) - (9)].expr).addr,0,(yyvsp[(2) - (9)].expr).addr,0);
								code(GT,(unsigned int) (yyvsp[(2) - (9)].expr).addr,(unsigned int)(yyvsp[(6) - (9)].expr).addr, NULL,0);
								
							;}
    break;

  case 65:

/* Line 1455 of yacc.c  */
#line 237 "06.7.y"
    {
											 //printf("<%d>back patch by: %d\n", __LINE__, *$<nxtq>2);
											 backPatch((yyvsp[(6) - (6)].nl), (yyvsp[(2) - (6)].nxtq));
											 backPatch((yyvsp[(3) - (6)].bexp).tl, (yyvsp[(5) - (6)].nxtq));
											 (yyval.nl)=(yyvsp[(3) - (6)].bexp).fl; code(0, 0,0, (symnode *)*(yyvsp[(2) - (6)].nxtq), 0)
										;}
    break;

  case 69:

/* Line 1455 of yacc.c  */
#line 250 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
								code(PLUS,  (unsigned int)(yyvsp[(1) - (3)].expr).addr, (unsigned int)(yyvsp[(3) - (3)].expr).addr, (yyval.expr).addr, 0);;}
    break;

  case 70:

/* Line 1455 of yacc.c  */
#line 252 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);	
     							code(MINUS, (unsigned int)(yyvsp[(1) - (3)].expr).addr,(unsigned int) (yyvsp[(3) - (3)].expr).addr, (yyval.expr).addr, 0);;}
    break;

  case 71:

/* Line 1455 of yacc.c  */
#line 254 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							code(MULT, (unsigned int) (yyvsp[(1) - (3)].expr).addr, (unsigned int)(yyvsp[(3) - (3)].expr).addr, (yyval.expr).addr, 0);;}
    break;

  case 72:

/* Line 1455 of yacc.c  */
#line 256 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							code(DIV,   (unsigned int)(yyvsp[(1) - (3)].expr).addr, (unsigned int)(yyvsp[(3) - (3)].expr).addr, (yyval.expr).addr, 0);;}
    break;

  case 73:

/* Line 1455 of yacc.c  */
#line 258 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							code(MOD,  (unsigned int) (yyvsp[(1) - (3)].expr).addr, (unsigned int)(yyvsp[(3) - (3)].expr).addr, (yyval.expr).addr, 0);;}
    break;

  case 74:

/* Line 1455 of yacc.c  */
#line 260 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							code(MINUS,(unsigned int)(yyvsp[(2) - (2)].expr).addr, 0, (yyval.expr).addr, 0);;}
    break;

  case 75:

/* Line 1455 of yacc.c  */
#line 262 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							code(PLUS,(unsigned int) (yyvsp[(2) - (2)].expr).addr, 0, (yyval.expr).addr, 0);;}
    break;

  case 76:

/* Line 1455 of yacc.c  */
#line 264 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, dimList, NULL,0);
     							((yyval.expr).addr)->val=(yyvsp[(1) - (1)].integer);code(ASSIGN, 0, (yyvsp[(1) - (1)].integer), (yyval.expr).addr, 2);
     							((yyval.expr).addr)->value.var=(double)(yyvsp[(1) - (1)].integer);
     							((yyval.expr).addr)->val=1		
     					;}
    break;

  case 77:

/* Line 1455 of yacc.c  */
#line 269 "06.7.y"
    {;}
    break;

  case 78:

/* Line 1455 of yacc.c  */
#line 271 "06.7.y"
    {(yyval.expr).addr=(yyvsp[(2) - (3)].expr).addr;}
    break;

  case 79:

/* Line 1455 of yacc.c  */
#line 272 "06.7.y"
    {(yyval.expr).addr=searchInsert(currentSymT, USE, (yyvsp[(1) - (1)].string), INTEGER, NULL, NULL,0);dimList[0]=-1;;}
    break;

  case 80:

/* Line 1455 of yacc.c  */
#line 273 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER,NULL, NULL,0);
     							code(MINUS, (unsigned int)(yyvsp[(2) - (2)].expr).addr, 1, (yyval.expr).addr, 2);;}
    break;

  case 81:

/* Line 1455 of yacc.c  */
#line 275 "06.7.y"
    {((yyval.expr).addr)=searchInsert(currentSymT, USE, genTemp(), INTEGER, NULL, NULL,0);
     							code(PLUS, (unsigned int)(yyvsp[(2) - (2)].expr).addr, 1, (yyval.expr).addr, 2);;}
    break;

  case 82:

/* Line 1455 of yacc.c  */
#line 277 "06.7.y"
    {;}
    break;

  case 88:

/* Line 1455 of yacc.c  */
#line 288 "06.7.y"
    {(yyval.nxtq)=(int*)malloc(4); *((yyval.nxtq))=nq;;}
    break;

  case 89:

/* Line 1455 of yacc.c  */
#line 290 "06.7.y"
    {(yyval.nl)=makeList(nq);code(0, 0,0, NULL, 0);;}
    break;



/* Line 1455 of yacc.c  */
#line 2135 "06.7.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 292 "06.7.y"



int main()
{  
  setlineNo(&ln);
  currentSymT=rootSymT=newSymTab(currentSymT);
  yyparse();
printf("\n\n#############SYMBOL TABLE###################\n");
	printId(currentSymT);	//For printing symbol table
	printTAC();			// For printing Three address code.
	FILE *fp=fopen("prog.s", "w");
	writeVerbatim(0,fp);
	writeVerbatim(1,fp);
	fclose(fp);
  return 0;
}

List *insert(List *root, symnode *val)
{
	List *node=(List *)malloc(sizeof(List));
	List *tmp=root;
	node->val=(unsigned int)val;
	while(tmp->next) tmp=tmp->next;
	tmp-> next=node;
	return root;
}


//InterCode[][4]=	0, if both operands are address
//				1, if operand1 is value
//				2, if operand 2 is value
//				3, if both are value				
void code(int op, unsigned int op1,unsigned int op2, symnode * dest, int check){
	int t=InterCode[nq-1][0];
	if (op==ASSIGN && (op1!=0 && InterCode[nq-1][3]==(unsigned int)op1)) 
	{
		InterCode[nq-1][3]=(unsigned int)dest;
		_cnt_--;
	}
	else if(t==ASSIGN && ((symnode*)InterCode[nq-1][3])->symP[0]=='@' && InterCode[nq-1][4]==2){
		if(op1==InterCode[nq-1][3] && !(InterCode[nq][4]%2)) {
			InterCode[nq][1]=InterCode[nq-1][2];
			InterCode[nq][4]+=1;
		}
		else if(op2==InterCode[nq-1][3] && InterCode[nq][4]<2) {
			InterCode[nq][2]=InterCode[nq-1][2];
			InterCode[nq][4]+=2;
		}
	}
	else{
		InterCode[nq][0]=op;
		InterCode[nq][1]=(unsigned int)op1;
		InterCode[nq][2]=(unsigned int)op2;
		InterCode[nq][3]=(unsigned int)dest;
		if(!op) makeLabel(nq);
		nq++;
	}
}

void makeLabel(int l)
{
	
char * genTemp(){
	char *c;
	c=(char *)malloc(sizeof(char)*5);
	sprintf(c,"@t%d",_cnt_++);
	//printf("%d<<<%s>>>>\n",ln, c);
	return c;
}
int revOP(int op)
{
	switch(op){
		case EQ: return NE;
		case NE: return EQ; 
		case GT: return LE;
		case GE: return LT;
		case LT: return GE;
		case LE: return GT;
		default: 0;
	}
}
void printTAC()
{
	char *op[22] = {"GOTO", "INC", "DEC",  "PLUS", "MINUS", "MULT", "DIV", "OR", "EQ", "NE", "GT", "GE", "LT", 
		       "LE", "NOT", "AND", "CALL", "IN", "OUT", "MOD", "RETURN", "ASSIGN", "FETCH"};
	int i;
	int operator;
	
	printf("\n****Three Address Code.****\n");
	printf("Format:\tOperator OP1 OP2 Dest\n");
	char tac[20]="";
	for(i=0;i<nq;i++)
	{
		if(InterCode[i][0]) operator=InterCode[i][0]-INC+1;
		if(InterCode[i][4]==0)
			sprintf(tac,"%s%s\t", tac, op[operator]);
			if(!operator) sprintf(tac, "%s%s\t", tac,(unsigned int)InterCode[i][3]);
			else f
		if(operator==0) 
			printf("%3d.\tGOTO\t%d\n", i,(int)(InterCode[i][3]));
		else if(operator<=LE && operator>=EQ)
			printf("%3d.\tIF\t%s\t%s\t%s\tGOTO\t%d\n", i,((symnode *)InterCode[i][1])->symP, op[InterCode[i][0]-INC],
				 ((symnode *)InterCode[i][2])->symP, (int)(InterCode[i][3]));
		else if(operator==ASSIGN )
		{	if(InterCode[i][1]==0)
				printf("%3d.\t%s\t%d\t%s\n", i,op[InterCode[i][0]-INC], (int)InterCode[i][2], ((symnode *)InterCode[i][3])->symP);
			else
				printf("%3d.\t%s\t%s\t%s\n", i,op[InterCode[i][0]-INC], ((symnode *)InterCode[i][1])->symP, ((symnode *)InterCode[i][3])->symP);
		}
		else if(operator==IN || operator==OUT)
			printf("%3d.\t%s\t\t\t%s\n", i,op[InterCode[i][0]-INC],((symnode *)InterCode[i][3])->symP);
		else
			printf("%3d.\t%s\t%s\t%s\t%s\n", i,op[InterCode[i][0]-INC],((symnode *)InterCode[i][1])->symP,  
										((symnode *)InterCode[i][2])->symP, ((symnode *)InterCode[i][3])->symP);

	}
	printf("%3d\tEND\n", i);
	return ;
}

List *makeList(int num){
	List *t;
	//printf("making list: %d @ %d\n",num, ln);
	t=(List*)malloc(sizeof(List));
	t->val=num;
	t->next=NULL;
	return t;
}

List *mergeList(List *a, List *b){
	List *t;
	t=a;
	if(!t) a=b;
	else 
	{
		while(t->next) t=t->next;
		t->next=b;
	}
	return a;
}

void deleteList(List *a)
{	
	List *t=a;
	while(a)
	{
		t=a->next;
		free(a);
		a=t;
	}
	return ;
}

void writeVerbatim(int option, FILE *fp){
  if(option==0)//initial part it will print
    fprintf(fp,
	    "\t.file   \"prog\"\n\
\t.section   .rodata\n\
\t.LC0:\n\
\t.string   \"%%d\"\n\
.LC1:\n\
\t.string   \"%%d\"\n\
.LC2:\n\
\t.string   \"%%d\"\n\
\t.text\n\
.globl main\n\
\t.type   main, @function\n\
main:\n\
\tpushl  %%ebp\n\
\tmovl   %%esp, %%ebp\n\
\tandl   $-16, %%esp\n"
	    );
  else if(option==1)//end part
    fprintf(fp,
	    "\n\tmovl   $0, %%eax\n\
\tleave\n\
\tret\n\
\t.size   main, .-main\n\
\t.ident   \"GCC: (Ubuntu 4.4.3-4ubuntu5) 4.4.3\"\n\
\t.section   .note.GNU-stack,\"\",@progbits\n"
	    );
  return ;
}
void backPatch(List *a, int* val)
{
  List *t;
  t=a;
  while(t != NULL){
    //printf("<#%d#> %d>>%d..\n",ln, t->val, *val);
    InterCode[t->val][3]=*val;
    t=t->next;
  }
  deleteList(a);
  return ;
}

void yyerror(char const *s) {fprintf(stderr, "%s @ lin No. %d\n", s, ln);}

