#include "symTab.h"
#include <stdio.h>
#include <string.h>
int hash(const char *a);
int printId(symtab *stP);
void copystring(char *des, char *src);
int *lineno;
void setlineNo(int * ln)
{
	lineno=ln;
	return ;
}

symtab* newSymTab(symtab *uP)
{
  symtab* tab=(symtab*)malloc(sizeof(symtab));
  if(uP) {
  	uP->downTab=tab;
  	tab->upTab=uP;
  }
  else uP=tab;
  int i;
  for(i=0;i<BUCKET_COUNT;i++){
  	tab->bucket[i]=NULL;
	}
  return tab;
}

void copystring(char *des, char *src)
{
	des=(char*)malloc(sizeof(char)*(strlen(src)+1));
	//printf("%s: %d\n", src, strlen(src));
	strcpy(des,src);
//	des[strlen]=\'\0'
	
	return ;
}
int hash(const char *a){
  int i=0, sum=0;
  while(a[i]!='\0')
    sum+=a[i++];
  return sum%BUCKET_COUNT;
}

void printSymnode(symnode *smN)
{	
	char *type[2]={"INTEGER", "DOUBLE"};
  	symnode *t=smN;
	printf("ID:%s\n",t->symP);
	if(t->defined==DEF)
	  printf("Defined: yes\n");
	else 
	  printf("Defined: no\n");
	printf("Type: %s\t", type[t->type/4-1]);
	printf("Base Size: %d\n", t->baseSize);
	if(t->dimList){
	printf("Dimention List: ");
	  int i=0;
	  while(t->dimList[i]>0){
	    printf("%d ", t->dimList[i++]);
	}
	}
	printf("\nOffset: %d\n__________________________\n",t->offset);
	return ;
} 
int printId(symtab *stP){
  int i,j,k;
  char *type[2]={"INTEGER", "DOUBLE"};
  char *define[3]={"Yes","No","Re"};
  symnode *t;
  printf("index\tIDname\t  Type\t\tDefined\tOffset\tDimlist\n");
  printf("-----\t------\t-------\t\t-------\t-----\t-------\n");
  if(!stP) {
  	printf("\n::::Nothing in thre table\n");return -1;}
  for(i=0;i<BUCKET_COUNT;i++){
    t=(stP->bucket[i]);j=0;
    while(t){
      printf("%3d.%-2d\t %s\t",i,j,t->symP);
      printf("%s\t\t", type[t->type/4-1]);
     /* if(t->defined==DEF)
		printf(" Yes\t");
      else if(t->defined==RE_DEF)
      	printf(" Redef\t");
	else  printf(" No\t");*/
	printf(" %s\t% 3d\t", define[t->defined], t->offset);
	
      if(t->dimList){
	k=0;
	while(t->dimList[k]>0)
	  printf("[%d]", t->dimList[k++]);
	printf("\n");
	//printf("\t %lf\n",t->value.var);
      } 
      t=t->next;j++;
    }
  }
  return ;
}

int printId1(symtab *stP){
  int i,j;
  char *type[2]={"INTEGER", "DOUBLE"};
  symnode *t;
  if(!stP) {
  	printf("\n::::Nothing in thre table\n");return -1;}
  for(i=0;i<BUCKET_COUNT;i++){
    t=(stP->bucket[i]);
    while(t){
	printf("\nID:%s\n",t->symP);    printf("line %d\n", __LINE__);
	if(t->defined==DEF)
	  printf("Defined: yes\n");
	else 
	  printf("Defined: no\n");
	printf("Type: %s\t", type[t->type/4-1]);
	printf("Base Size: %d\n", t->baseSize);
	
	if(t->dimList){
	  int i=0;printf("Dimention List: ");
	  while(t->dimList[i]>0)
	    printf("%d ", t->dimList[i++]);
	}
	printf("\nOffset: %d\n__________\n",t->offset);
    t=t->next;
    }
    
  } 
  return 0;
}
symnode *searchInsert(symtab *stP, char contxt, const char *varP, 
		      int type, int *dimL, int *errP, int offset)
{
//printf("We are in searchInsert: <%d, %s, %d> \n",contxt,  varP, type);

  int stHashIndex = hash(varP);
  symnode**  snTempP = &(stP->bucket[stHashIndex]);
  int idFound = 0;
  
 
  while(*snTempP)
  {
  	if(strcmp((*snTempP)->symP, varP)==0)
	{idFound = 1;break;}
	else snTempP = &((*snTempP)->next);
  }
  //printf("line 5d\n", __LINE__);
  if(idFound && contxt == DEF){
    //return snTempP;
    (*snTempP)->defined=RE_DEF;
    printf("Redefinintion error @ line bo. %d.\n", *lineno);
  }
  if(idFound && contxt == USE);
    //return snTempP;
    //printf("Ok\n");
  if(!idFound && contxt == DEF)
    {
      //make an entry
      (*snTempP)=createNode(stP, contxt, varP, type, dimL,errP, offset);
      //return OK;
      //printf("Inserted\n");
    }
  
  if(!idFound && contxt == USE)
    {	
      //make an un_Def entry
      (*snTempP)=createNode(stP, contxt, varP, type, dimL,errP, offset);
      //return NOT_DEF;
        //printf("NOt defined : %s @ line no %d\n", varP, *lineno);
    }
    return (*snTempP);
}

symnode *createNode(symtab *stP, char contxt, const char *varP, int type, int *dimL, int *errP, int offset)
{
  symnode *snNew= (symnode* )malloc(sizeof(symnode));
  snNew->symP = (char *)malloc(sizeof(strlen(varP)));

  strcpy(snNew->symP, varP);
  snNew->type = type;
  //  snNew->symP = (char *)malloc(sizeof(dim));
  //strcpy(snNew->symP, varP);
  int i=0;
  if(dimL){
	while(dimL[i]>0)
	  snNew->dimList[i] = dimL[i++];
	}
	snNew->dimList[i] = -1;
	
	snNew->offset=offset;
	//if(dimL) snNew->dimList[i] = dimL[i];
	snNew->defined = (contxt == USE) ? NOT_DEF : OK;
	snNew->next=NULL;
  
  return snNew;
}
/*
int insertInStringTab(char *c)
{
  str[499]='$';
  int i=0;
  int len=strlen(c);
  if(len<499-ptr){
    while(c[i]) str[ptr++]=c[i++];
    str[ptr++]='\0';
  }
*/
