#ifndef SYMTAB_H
#define SYMTAB_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define BUCKET_COUNT 256

#define INTEGER 4
#define DOUBLE 8
#define FUNC 12
#define YES 1
#define NO 0
#define COMP_TEMP 3
#define OK 0
#define NOT_DEF 1
#define RE_DEF 2
#define DEF 1
#define USE 20

struct symNode {
  char *symP ;  // id string
  char defined ;  // defined, compiler generated temporary
  int type ;  // base type name
  int baseSize ;  // base type size
  int dimList[20];  // nil for scalar, dimension list for array
  int offset;  // relative offset in data area
  int val;	
  union {
    double var;           /* value of a VAR          */
    double (*fnctptr)();  /* value of a FNCT         */
  }value;
  struct symNode *next; // you may change the singly linked list
                       // to create a doubly linked list.
};
 typedef struct symNode symnode;
struct symTab {
  struct symNode* bucket[BUCKET_COUNT];
  struct symTab *upTab, *downTab ;
};
typedef struct symTab symtab;
symtab *newSymTab(symtab *);
symnode *searchInsert(symtab *, char, const char *, int, int *, int *, int);
// pointer to symbol table, identifier string, base type,// dimension list - nil if not an array.
int printId(symtab *); // prints the identifiers with all other information.

symnode *createNode(symtab *stP, char contxt, const char *varP, int type, int *dimL, int *errP, int);
symtab* newSymTab(symtab *uP);
void setlineNo(int * ln);
typedef struct lst{
    int val;
    struct lst *next;
  }List;

typedef struct stringTab{
  char str[500];
  int ptr;
  char *next;
}strTab;

#endif

