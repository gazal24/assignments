#include<stdio.h>
#include<stdlib.h>
#include"lex.yy.c"


/* enum terminal{START=1, END, CODE, ID, VAR, INT,   FLOAT,  SEMICOLON,//8 */
/* 	      SQRBKT,  DOT, PLUS, IN, NOT, LT,    COLON,  INTCONST, //16 */
/* 	      STRING,  FOR, STEP, TO, OUT, LE,    WHILE,  ASSIGN,   //24 */
/* 	      LPAREN,  DIV, MULT, EQ, MOD, IF,    MINUS,  FLOATCONST,//32 */
/* 	      SQLBKT,  ELSE,RPAREN //35 */
/* };//35 terminals */
/* enum nonterminal{prog=100, progH, pID, body, varDecl, vdclList, vdclList1,  */
/* 		 typeVar, type, idList, idList1, idNam, dimList, dimList1, */
/* 		 dim, stmts, stmtList, stmtList1, stmt, assStmt, idV, indList, */
/* 		 indx,  compStmt, ifStmt, elsePart, boolExp, relOp, whileStmt,  */
/* 		 forStmt, contVar, inStmt, inStr, inStrOpt, outStmt, outStr,  */
/* 		 outStrOpt,exp, term, term1, fact, indList1, exp1 */
/* };//43 non-terminals */

int G[][10]={{progH, START, body, END},//0
	     {CODE, pID},//1
	     {ID},
	     {varDecl, stmts},
	     {VAR, vdclList, SEMICOLON},
	     {typeVar, vdclList1},
	     {type, idList},
	     {INT},
	     {FLOAT},
	     {idNam, idList1},//9
	     {ID, dimList},
	     {dimList1},
	     {dim, dimList1},
	     {SQLBKT, INTCONST, SQRBKT},
	     {stmtList, DOT},
	     {stmt, stmtList1},
	     {assStmt},
	     {compStmt},
	     {ifStmt},
	     {whileStmt},//19
	     {forStmt},
	     {inStmt},
	     {outStmt},
	     {idV, ASSIGN, exp},
	     {ID, indList},
	     {indList1},//25
	     {indx, indList1},
	     {SQLBKT, exp, SQRBKT},
	     {START, stmtList, END},
	     {IF, boolExp, COLON, stmt, elsePart},//29
	     {ELSE, stmt},
	     {NOT, boolExp},
	     {exp, relOp, exp},
	     {EQ},
	     {LT},
	     {LE},//35
	     {WHILE, boolExp, COLON, stmt},
	     {FOR, contVar, ASSIGN, exp, TO, exp, STEP, exp, stmt},
	     {idV},//38
	     {IN, inStr},
	     {idV, inStrOpt},//40
	     {COLON, inStr},
	     {OUT, outStr},
	     {idV, outStrOpt},
	     {STRING, outStrOpt},
	     {COLON, outStr },
	     {term, exp1},
	     {PLUS, term, exp1},//47
	     {MINUS, term,  exp1},
	     {fact, term1},
	     {MULT, fact, term1},//50
	     {DIV, fact, term1},
	     {MOD, fact,  term1},
	     {LPAREN, exp, RPAREN},
	     {INTCONST},
	     {FLOATCONST},//55
	     {idV},
	     {-1}// =>EPSILON
};

int T[50][50];

void FirstOfStmt(int pos, int val){
  T[pos-100][ID]=T[pos-100][START]=T[pos-100][IF]=T[pos-100][WHILE]=val;
  T[pos-100][FOR]=T[pos-100][IN]=T[pos-100][OUT]=val;
  return ;
}

void FollowOfTerm(int pos, int val){
  T[pos-100][DOT]=T[pos-100][SQRBKT]=T[pos-100][EQ]=T[pos-100][LT]=val;
  T[pos-100][LE]=T[pos-100][TO]=T[pos-100][STEP]=T[pos-100][PLUS]=val;
  T[pos-100][MINUS]=T[pos-100][RPAREN]=val;
  FirstOfStmt(pos, val);
  return ;

}

void makeTable(){
  T[prog-100][CODE]=0;
  T[progH-100][CODE]=1;
  T[pID-100][ID]=2;
  T[body-100][VAR]=3; FirstOfStmt(body, 3);
  T[varDecl-100][VAR]=4; FirstOfStmt(varDecl, 57);
  T[vdclList-100][INT]=T[vdclList-100][FLOAT]=5;
  T[vdclList1-100][INT]=5; T[vdclList1-100][FLOAT]=5; T[vdclList1-100][SEMICOLON]=57;
  T[typeVar-100][INT]=6;T[typeVar-100][FLOAT]=6;
  T[type-100][INT]=7;T[type-100][FLOAT]=8;
  T[idList-100][ID]=9;
  T[idList1-100][ID]= 9;
  T[idList1-100][FLOAT] = T[idList1-100][INT] = T[idList1-100][SEMICOLON] = 57;
  T[idNam - 100][ID] = 10;
  T[dimList - 100][SQLBKT] = 11;    
  T[dimList-100][FLOAT] = T[dimList-100][INT] = T[dimList-100][SEMICOLON] = T[dimList-100][ID] = 57;
  T[dimList1 - 100][SQLBKT] = 12;    
  T[dimList1-100][FLOAT] = T[dimList1-100][INT] = T[dimList1-100][SEMICOLON] = T[dimList1-100][ID] = 57;
  T[dim - 100][SQLBKT] = 13;      
  T[stmts - 100][DOT] = 14; FirstOfStmt(stmts, 14);
  FirstOfStmt(stmtList, 15);  
  FirstOfStmt(stmtList1, 15);
  T[stmtList1 - 100][DOT] =  T[stmtList1 - 100][END] = 57; 
  T[stmt - 100][ID] = 16;   
  T[stmt - 100][START] = 17;
  T[stmt - 100][IF] = 18;
  T[stmt - 100][WHILE] = 19;//<sahiii>
  T[stmt - 100][FOR] = 20;
  T[stmt - 100][IN] = 21;
  T[stmt - 100][OUT] = 22;
  T[assStmt - 100][ID] = 23;
  T[idV - 100][ID] = 24;  
  T[indList - 100][SQLBKT] = 25; 
  T[indList - 100][ASSIGN] = T[indList - 100][COLON] = 57; FollowOfTerm(indList, 57);
  T[indList1 - 100][SQLBKT] = 26; 
  T[indList1- 100][ASSIGN] = T[indList1 - 100][COLON] = T[indList1 - 100][MULT]=57; 
  T[indList1 - 100][DIV]=T[indList1 - 100][MOD]=57;
  FollowOfTerm(indList1, 57); 
  T[indx-100][SQLBKT] = 27;
  T[compStmt-100][START] = 28;
  T[ifStmt-100][IF] = 29;
  T[elsePart-100][ELSE] = 30; T[elsePart-100][DOT] = 57;
  T[boolExp-100][NOT] = 31;
  T[boolExp-100][LPAREN]=T[boolExp-100][INTCONST]=T[boolExp-100][ID]=T[boolExp-100][FLOATCONST]=32;
  T[relOp-100][EQ] = 33;
  T[relOp-100][LT] = 34;
  T[relOp-100][LE] =  35;
  T[whileStmt-100][WHILE] = 36;
  T[forStmt-100][FOR] = 37;
  T[contVar-100][ID] = 38;
  T[inStmt-100][IN] = 39;
  T[inStr-100][ID] = 40;
  T[inStrOpt-100][COLON] = 41; T[inStrOpt-100][DOT] = 57;
  T[outStmt-100][OUT] = 42;
  T[outStr-100][ID] = 43;
  T[outStr-100][STRING] = 44;  
  T[outStrOpt-100][COLON] = 45; T[outStrOpt-100][DOT] = 57;
  T[exp-100][LPAREN] = T[exp-100][INTCONST] = T[exp-100][ID] = 46; 
  FollowOfTerm(exp1, 57);  
  T[exp1-100][PLUS] = 47;
  T[exp1-100][MINUS] = 48;
  T[term-100][LPAREN] = T[term-100][INTCONST] = T[term-100][FLOATCONST] = T[term-100][ID] = 49;
  T[term1-100][MULT] = 50;
  T[term1-100][DIV] = 51;
  T[term1-100][MOD] = 52;
  FollowOfTerm(term1, 57);
  T[fact-100][LPAREN] = 53;
  T[fact-100][INTCONST] = 54;
  T[fact-100][FLOATCONST] = 55;
  T[fact-100][ID] = 56;
  return ;
}


typedef struct stack{
  int val;
  struct stack * next;
}STACK;
//typedef struct stack STACK;
void exit_error(int line_no, int errorType){
  if(errorType==0){// due to looking for correct terminal
    printf("Error in terminal matchig @ Line no. %d \n", line_no);
    exit(-1);
  }
  else if(errorType==1){//due to table entry error
    printf("Error in Table matching @ Line no. %d\n", line_no);
    exit(-1);
  }
  return ;
} 
void exit_success(){
  printf("Parsing Completed successfully\n");
  return;
}
void show_stack(STACK *st){
  STACK* t;
  t=st;
  while(t){
    printf("%d->",t->val);
    t=t->next;
  }
  printf("\b\b\n");
  return ;
}

void parser(){
  int token, current,i,j;
  STACK *st, *top, *tmp;
  st=(STACK *)malloc(sizeof(STACK));
  tmp=(STACK *)malloc(sizeof(STACK));
  st->val=EOF;st->next=NULL;top=st;
  tmp->val=prog;tmp->next=top;top=tmp;
  token=yylex();
  while(token){
    show_stack(top);
    printf("TOKEN %s(%d)\n", yytext,token);
    current=top->val;top=top->next;
    if(current==EOF && token==EOF) 
      return exit_success();
    if(current<60){
      if(token==current){ 
	token=yylex();
	continue;
      }
      else {printf("[%d <-> %d]\n",current,token);exit_error(ln,0);}//exit_error(int line_no, int errorType){}
    }
    else if((i=T[current-100][token])>-1){
      if(G[i][0]==-1) continue;
      st=top;
      tmp=(STACK *)malloc(sizeof(STACK));
      tmp->val=G[i][0];
      top=tmp;
      j=1;
      while(G[i][j]>0){
	tmp->next=(STACK *)malloc(sizeof(STACK));
	tmp=tmp->next;
	tmp->val=G[i][j++];
	printf("<%d>",G[i][j-1]);
      }
      tmp->next=st;
    }
    else 
      exit_error(ln,1);//
  }
  return ;
}

int main()
{
 makeTable(); 
 for(int i=0;i<50;i++){
    for(int j=0;j<50;j++){
      if( T[i][j] ==0) T[i][j] = -2;
      printf("%d ", T[i][j]);
    }
    printf("\n");
  }
  T[0][CODE]=0;
 
  parser();
  nonterminal s;

  return 0;
}
