#ifndef _Y_TAB_H
#define _Y_TAB_H

/* /\* Tokens: identifier, integer constant, floating-point constant, */
/*            operators  */
/*  *\/ */
/* #define IDNTIFIER 300 */
/* #define INT_CONST 310 */
/* #define FLO_CONST 320 */

/* /\* Tokens:  := ; : , . ( ) [ ] { }  */
/*  *\/ */
/* #define ASSIGN    400  */
/* #define SEMICOLON 410 */
/* #define COLON     420  */
/* #define COMMA_MRK 430  */
/* #define DOT       440 */
/* #define LFT_PARAN 450  */
/* #define RGT_PARAN 460  */
/* #define L_SQR_BKT 470  */
/* #define R_SQR_BKT 480  */
/* #define LFT_BRACE 490  */
/* #define RGT_BRACE 500 */

/* /\* Tokens for keywords: code eloop end float for if in int nil out proc start  */
/*                         step to var while */
/*  *\/ */
/* #define CODE    600 */
/* #define EXLOOP  610 */
/* #define END     620 */
/* #define FLOAT   630 */
/* #define FOR     640 */
/* #define IF      650 */
/* #define IN      660 */
/* #define INT     670 */
/* #define NIL     680 */
/* #define OUT     690  */
/* #define PROC    700 */
/* #define START   710 */
/* #define STEP    720 */
/* #define TO      730 */
/* #define VAR     740 */
/* #define WHILE   750 */
 
/* /\* Operator Attribute values: + - * / mod = < <= not ++ -- */
/*  *\/ */

/* #define PLUS   1000 */
/* #define MINUS  1010 */
/* #define MULT   1020 */
/* #define DIV    1030 */
/* #define MOD    1040 */
/* #define EQUL   1050 */
/* #define LESS   1060 */
/* #define LEQ    1070 */
/* #define NOT    1080 */
/* #define INC    1090 */
/* #define DEC    1100 */

enum terminal{START=1, END, CODE, ID, VAR, INT,   FLOAT,  SEMICOLON,//8
	      SQRBKT,  DOT, PLUS, IN, NOT, LT,    COLON,  INTCONST, //16
	      STRING,  FOR, STEP, TO, OUT, LE,    WHILE,  ASSIGN,   //24
	      LPAREN,  DIV, MULT, EQ, MOD, IF,    MINUS,  FLOATCONST,//32
	      SQLBKT,  ELSE,RPAREN //34
};//35 terminals
enum nonterminal{prog=100, progH, pID, body, varDecl, vdclList, vdclList1, //106
		 typeVar, type, idList, idList1, idNam, dimList, dimList1,//113
		 dim, stmts, stmtList, stmtList1, stmt, assStmt, idV, indList,//121
		 indx,  compStmt, ifStmt, elsePart, boolExp, relOp, whileStmt, //128
		 forStmt, contVar, inStmt, inStr, inStrOpt, outStmt, outStr, //135
		 outStrOpt,exp, term, term1, fact, indList1, exp1 //142
};//43 non-terminals


typedef union {
       char *string;
       int integer;
       double real;
} yylType;

int yylex(void);
int ln;
#endif
