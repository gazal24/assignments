/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     CALL = 258,
     START = 259,
     END = 260,
     CODE = 261,
     INT = 262,
     FLOAT = 263,
     STRING = 264,
     VAR = 265,
     WHILE = 266,
     FOR = 267,
     EXITLOOP = 268,
     SKIP = 269,
     IF = 270,
     ELSE = 271,
     PROTO = 272,
     PROC = 273,
     TO = 274,
     STEP = 275,
     IN = 276,
     OUT = 277,
     NIL = 278,
     NOT = 279,
     MOD = 280,
     RETURN = 281,
     AND = 282,
     ASSIGN = 283,
     INC = 284,
     DEC = 285,
     PLUS = 286,
     MINUS = 287,
     MULT = 288,
     DIV = 289,
     OR = 290,
     EQ = 291,
     NE = 292,
     GT = 293,
     GE = 294,
     LT = 295,
     LE = 296,
     LFT_PAREN = 297,
     RGT_PAREN = 298,
     LFT_BRACE = 299,
     RGT_BRACE = 300,
     LFT_SQ_BKT = 301,
     RGT_SQ_BKT = 302,
     COMMA = 303,
     COLON = 304,
     SEMICOLON = 305,
     DOT = 306,
     INT_CONST = 307,
     FLOAT_CONST = 308,
     IDENTIFIER = 309,
     UPOS = 310,
     UNEG = 311
   };
#endif
/* Tokens.  */
#define CALL 258
#define START 259
#define END 260
#define CODE 261
#define INT 262
#define FLOAT 263
#define STRING 264
#define VAR 265
#define WHILE 266
#define FOR 267
#define EXITLOOP 268
#define SKIP 269
#define IF 270
#define ELSE 271
#define PROTO 272
#define PROC 273
#define TO 274
#define STEP 275
#define IN 276
#define OUT 277
#define NIL 278
#define NOT 279
#define MOD 280
#define RETURN 281
#define AND 282
#define ASSIGN 283
#define INC 284
#define DEC 285
#define PLUS 286
#define MINUS 287
#define MULT 288
#define DIV 289
#define OR 290
#define EQ 291
#define NE 292
#define GT 293
#define GE 294
#define LT 295
#define LE 296
#define LFT_PAREN 297
#define RGT_PAREN 298
#define LFT_BRACE 299
#define RGT_BRACE 300
#define LFT_SQ_BKT 301
#define RGT_SQ_BKT 302
#define COMMA 303
#define COLON 304
#define SEMICOLON 305
#define DOT 306
#define INT_CONST 307
#define FLOAT_CONST 308
#define IDENTIFIER 309
#define UPOS 310
#define UNEG 311




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 10 "06.5.y"
{                /* type of 'yylval' (stack type)*/
  char *string;
  int integer;           /* type name is YYSTYPE*/
  double real;            /* default #define YYSTYPE int ple ty*/
}
/* Line 1489 of yacc.c.  */
#line 167 "06.5.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

